public class Fourmi extends Insect {
    public void seDeplacer(){
        System.out.println("La fourmi marche");
    }
    public void travailler(){
        System.out.println("La fourmi travaille");
    }

}
