public class FourmiAilee extends Fourmi implements Volant {

    @Override
    public void voler() {
        System.out.println("La fourmi vole");
    }
    public void seDeplacer(){
        voler();
    }
}
