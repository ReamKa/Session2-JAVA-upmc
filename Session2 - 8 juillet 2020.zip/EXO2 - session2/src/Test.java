public class Test {

    public static void main(String[] args) {
        //2.1
        // Insect ins1 = new Insect(); FAUX car Insect est une classe abstraite
        Insect ins2 = new Fourmi();
        Insect ins3 = new FourmiAilee();
        // Insect ins4 = new Volant(); FAUX car Volant est abstrait

        //Volant v1 = (Volant)new Fourmi(); EXEC Fourmi n'est pas une sous-classe de Volant
        Volant v2 = new FourmiAilee();
        //FourmiAilee v3 =  new Fourmi(); FAUX car Fourmi est la classe mère
        //Insect ins5 = (Volant)new FourmiAilee(); FAUX

        //2.2
        Fourmi f1 = new Fourmi();
        Fourmi f2 = new FourmiAilee();
        Insect insF1 = f1;
        Insect insF2 = f2;


        f1.manger();
        //insF1.travailler(); COMPIL : methode travailler n'existe pas dans insecte
        f1.seDeplacer();
        insF1.seDeplacer();
        //f1.voler(); COMPIL : fourmi n'est pas caster à Volant donc f1 ne peut pas accédder à la methode de l'interface
        //((FourmiAilee)insF1).voler(); //EXEC Fourmi ne peut pas etre caster en FourmiAilee (l'inverse si)

        f2.travailler();
        ((Fourmi)insF2).travailler();
        f2.seDeplacer();
        ((Fourmi)insF2).seDeplacer();
        //f2.voler(); COMPIL : f2 est une fourmi qui n'implemente pas Volant et qui n'est pas caster en Volant ou FourmiAilee
        ((FourmiAilee)insF2).voler();


    }
}

