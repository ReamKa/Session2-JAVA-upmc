public abstract class Insect {
    public abstract void seDeplacer();
    public void manger(){
        System.out.println("L'insecte mange");
    }
}
