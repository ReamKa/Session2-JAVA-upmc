public class TestBizarreException {
    private static boolean varX, varY;
    public static void testA() throws BizarreException{
        if (varX) throw new BizarreException("testA","varX est vrai");
        System.out.println("Fin testA");
    }
    public static void testB(){
        try {
            varX = true;
            testA();
        } catch (BizarreException e){
            System.out.println("catch testB :  "+ e.getMessage());
            throw new RuntimeException("testB");
        }
        System.out.println("Fin testB");
    }
    public static void main(String[] args) throws BizarreException{
        varX = true; varY = true;
        while(varY){
            try{
                testA();
                testB();
            } catch (BizarreException e) {
                System.out.println("catch main BizarreException : "+e.getMessage());
                varX = false;
            } catch (Exception e){
                System.out.println("catch main Exception : " + e.getMessage());
                varY = false;
            }
        }
        ESystem.out.println("Fin main");
    }
}
