public class BizarreException extends Exception {
    private String nomMethode;
    private String message;

    public BizarreException(String nomMethode, String message){
        this.nomMethode = nomMethode;
        this.message = message;
    }
    public String getMessage(){
        return "<<"+nomMethode+">>" + " : " + "<<" + message+">>";
    }
}
