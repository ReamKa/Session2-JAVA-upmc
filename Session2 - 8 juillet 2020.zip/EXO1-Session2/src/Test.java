import java.util.Arrays;

public class Test {
    public static void main (String [] args){
        Poule p1 = new Poule();
        Oeuf o1 = p1.pondre();
        Oeuf[] boite = new Oeuf [4];
        boite[0]= p1.pondre();
        boite[1] = boite[0];
        boite[0]=null;
        boite[2]=o1;
        boite[3]=p1.pondre();
        boite[3] = null;

        for(int i = 0; i < boite.length;i++){
            System.out.println(boite[i]);
        }

        System.out.println(o1.POIDSFROSOEUFS);
        // System.out.println(o1.cptOeufs); FAUX
        System.out.println(o1.numero);
        // System.out.println(o1.poids); FAUX
        System.out.println(o1.getCptOeufs());

        System.out.println(Oeuf.POIDSFROSOEUFS);
        //System.out.println(Oeuf.cptOeufs); FAUX
        // System.out.println(Oeuf.numero); FAUX
        // System.out.println(Oeuf.poids); FAUX
        System.out.println(Oeuf.getCptOeufs());

        //1.5
        Oeuf un = new Oeuf();
        Oeuf deux = new Oeuf(50);
        Oeuf trois = new Oeuf(10);

        System.out.println(un.equals(deux));
        System.out.println(deux.equals(trois));

        //1.6
        Oeuf[][] tabOeufs = new Oeuf[5][];
        for(int i = 0; i < tabOeufs.length;i++){
            tabOeufs[i] = new Oeuf[i+1];
            for (int j = 0; j <tabOeufs[i].length; j++){
                tabOeufs[i][j] = new Oeuf();
            }
        }
        System.out.println(Arrays.deepToString(tabOeufs));

        //1.7
        o1.eclore();
        o1.eclore();
        un.eclore();
        deux.eclore();
    }
    }

