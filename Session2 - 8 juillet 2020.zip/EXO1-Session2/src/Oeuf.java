    public class Oeuf {
        public static final int POIDSFROSOEUFS = 63;
        private static int cptOeufs = 0;
        public final int numero;
        private int poids;
        private boolean eclosion = false;

        public Oeuf(int poids) {
            this.poids = poids;
            cptOeufs++;
            numero = cptOeufs;
        }

        public Oeuf() {
            this(50);
        }

        public static int getCptOeufs() {
            return cptOeufs;
        }

        @Override
        public String toString() {
            return "Oeuf{" +
                    "numero=" + numero +
                    ", poids=" + poids +
                    '}';
        }

        //1.5
        public boolean equals(Oeuf o) {
            return (this.poids == o.poids);
        }

        //1.7
        public void eclore(){
            if(!eclosion){
                eclosion = true;
                new Poule();
                System.out.println("new poule");
            } else {
                System.out.println("Impossible");
            }
        }
    }
