public class Poule {
    private boolean eclosion = false;

    public Oeuf pondre() {
        return new Oeuf();
    }

}
