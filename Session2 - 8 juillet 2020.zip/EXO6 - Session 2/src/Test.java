public class Test {
    public static void main (String [] args) {
        //6.2
        Point p = new Point(1, 2);
        Point p3d = new PointZ(2, 2, 2);
        PointZ depl = new PointZ(1, 1, 1);

        System.out.println(p);
        System.out.println(p3d);
        p.move(depl);
        p3d.move(depl);
        System.out.println(p);
        System.out.println(p3d);

        //p3d a utilisé le move() de Point car lors de la compilation, le byte-code a retenu la signature move(Point p)
        // qui est presénte dans la classe mere Point de p3d.

        //6.3
        Point p1 = new Point(1,2);
        Point p2 = new PointZ(1,2,3);
        PointZ pz1 = new PointZ(1,2,3);
        Point p3 = p2;
        PointZ pz2 = pz1;
        Point p4 = pz2;

        System.out.println((p2==p1) + "/" + p2.equals(p1));
        System.out.println((p2==p3)+"/"+ p2.equals(p3));
        System.out.println((p2==pz1) + "/"+ p2.equals(pz1));
        System.out.println((pz1==pz2) + "/" + pz1.equals(pz2));
        System.out.println((p4==pz1) + "/"+ p4.equals(pz1));

        //Test de la methode clone
        System.out.println("nouveau clone"+pz1.clone());
        System.out.println(pz2.clone());
    }
}
