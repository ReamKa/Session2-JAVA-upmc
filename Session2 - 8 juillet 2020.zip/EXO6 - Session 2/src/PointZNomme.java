public class PointZNomme  extends PointZ{
    private String nom;
    public PointZNomme(double x, double y, double z,String nom){
        super(x,y,z);
        this.nom = nom;
    }
    public String toString(){
        return super.toString() + "nom :" + nom;
    }
    /**
     * Pour la methode move tout depend de si on veut comparer QUE les coordonnées et dans ce cas là il n'est pas necessaire de
     * redefinir.
     * OIu si on veut comparer meme les noms, dans ce cas là, oui il faut redefinir equals, en precisant EN PREMIERE LIGNE
     * if(this.nom == p.nom) return true;
     */
}
