public class PointZ extends Point {
    private double z;
    public PointZ(double x, double y, double z) {
        super(x, y);
        this.z = z;
    }

    public void move(PointZ p) {
        super.move(p);
        z += p.z;
    }

    @Override
    public String toString() {
        return "PointZ{ x "+ getX() + "y "+getY() +
                "z=" + z +
                '}';
    }

    //6.5
    public PointZ clone(){
        return new PointZ(this.getX(), this.getY(), this.z);
    }
}
