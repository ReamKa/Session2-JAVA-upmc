public class Point {
    private double x,y;
    public Point(double x, double y){
        this.x = x;
        this.y = y;
    }
    public double getX(){return x;}
    public double getY(){return y;}

    @Override
    public String toString() {
        return "Point{" +
                "x=" + x +
                ", y=" + y +
                '}';
    }
    public void move (Point p ){
        x += p.x;
        y += p.y;
    }

    //6.3
    public boolean equals(Point p){
        if(this == p ) { return true;}
        if (getClass() == p.getClass()) {return true;}
        return false;
    }
}
